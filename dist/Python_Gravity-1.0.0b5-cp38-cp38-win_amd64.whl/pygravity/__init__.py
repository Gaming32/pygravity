"""pygravity is a library for simulating gravity in Python
It is written in Cython, for speed."""


__version__ = '1.0.0'
__author__ = 'Gaming32'
